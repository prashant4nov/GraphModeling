Neo4j Logs
=======================================

Server logs, including:

* console.log     -- stdout and stderr of the neo4j process
* neo4j.?.?.log   -- versioned log of the requests accepted by the Neo4j REST server,
                     controlled by conf/neo4j-http-logging.x
* wrapper.log     -- logging for the service wrapper

