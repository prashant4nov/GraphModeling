.. Tweepy documentation master file, created by
   sphinx-quickstart on Fri Apr 15 18:57:17 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Tweepy Documentation
====================

.. toctree::
   :maxdepth: 2

   install

